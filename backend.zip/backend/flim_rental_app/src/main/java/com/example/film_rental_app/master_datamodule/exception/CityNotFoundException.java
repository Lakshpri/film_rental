package com.example.film_rental_app.master_datamodule.exception;

import com.example.film_rental_app.common.exception.ResourceNotFoundException;

public class CityNotFoundException extends ResourceNotFoundException {
    public CityNotFoundException(Integer cityId) {
        super("City", cityId);
    }
}
